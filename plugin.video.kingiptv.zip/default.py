# -*- coding: utf-8 -*-

import os
import time
import json
import threading
from lib.helper import *
import inputstreamhelper
from lib import xtream, tunein, pluto, imdb, api_vod
from lib.proxy import UnifiedServer, PROXY_PORT

_proxy_server   = None
_proxy_lock     = threading.Lock()

def _start_proxy_if_needed():
    global _proxy_server
    if _proxy_server is not None:
        return PROXY_PORT
    with _proxy_lock:
        if _proxy_server is not None:
            return PROXY_PORT
        try:
            server = UnifiedServer(port=PROXY_PORT)
            t = threading.Thread(target=server.start)
            t.daemon = True
            t.start()
            _proxy_server = server
        except Exception:
            pass
    return PROXY_PORT
from lib.resolver import Resolver

try:
    from urllib import urlencode
except ImportError:
    from urllib.parse import urlencode

from lib.player import get_player
from lib.skipservice import prefetch_skip_timestamps
from lib.db_manager import KingDatabaseManager
from lib.loading_window import loading_manager

db_manager = KingDatabaseManager()
db_manager.check_auto_expiry()

from lib.database import KingDatabase

_db = None

def get_db():
    global _db
    if _db is None:
        _db = KingDatabase()
    return _db

_addon = xbmcaddon.Addon()

def getString(string_id):
    return _addon.getLocalizedString(string_id)

profile = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.kingiptv')

TITULO = '::: KING IPTV :::'
API_CHANNELS = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x64\x6f\x63\x73\x2e\x67\x6f\x6f\x67\x6c\x65\x2e\x63\x6f\x6d\x2f\x75\x63\x3f\x65\x78\x70\x6f\x72\x74\x3d\x64\x6f\x77\x6e\x6c\x6f\x61\x64\x26\x69\x64\x3d\x31\x67\x52\x53\x61\x72\x30\x49\x79\x32\x6f\x47\x65\x70\x4c\x33\x4c\x6b\x4d\x74\x43\x62\x77\x54\x7a\x67\x53\x67\x68\x41\x73\x77\x36'
API_RADIOS = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x69\x73\x74\x2e\x67\x69\x74\x68\x75\x62\x75\x73\x65\x72\x63\x6f\x6e\x74\x65\x6e\x74\x2e\x63\x6f\x6d\x2f\x69\x63\x61\x72\x6f\x6b\x39\x39\x2f\x64\x65\x38\x38\x63\x33\x66\x30\x61\x34\x31\x39\x64\x32\x35\x34\x30\x33\x62\x31\x31\x30\x65\x33\x64\x31\x32\x38\x37\x31\x65\x31\x2f\x72\x61\x77\x2f\x62\x65\x33\x32\x64\x65\x32\x37\x65\x63\x33\x36\x34\x39\x36\x30\x34\x37\x66\x30\x61\x33\x35\x64\x63\x31\x38\x65\x62\x34\x34\x65\x66\x37\x39\x65\x38\x66\x63\x33\x2f\x72\x61\x64\x69\x6f\x73\x2e\x6a\x73\x6f\x6e'

if not exists(profile):
    try:
        os.makedirs(profile)
    except OSError as e:
        if e.errno != 17:
            pass
IPTV_PROBLEM_LOG = translate(os.path.join(profile, 'iptv_problems_log.txt'))

def build_series_playlist(imdb_number, season_num, current_episode_num, serie_name, original_name, all_episodes):
    if not all_episodes or not isinstance(all_episodes, list):
        return
    if not isinstance(season_num, int) or not isinstance(current_episode_num, int):
        return

    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()

    for episode_data in all_episodes:
        if not isinstance(episode_data, dict):
            continue
        ep_num = episode_data.get('episode')
        if not ep_num or not isinstance(ep_num, int):
            continue

        name = episode_data.get('episode_title', '')
        img = episode_data.get('thumbnail', '')
        fanart = episode_data.get('fanart', '')
        description = episode_data.get('description', '')

        if ep_num >= current_episode_num:
            params = {
                'serie_name': serie_name,
                'original_name': original_name,
                'season_num': str(season_num),
                'episode_num': str(ep_num),
                'episode_title': name,
                'iconimage': img,
                'fanart': fanart,
                'imdbnumber': imdb_number,
                'description': description
            }

            plugin_url = 'plugin://plugin.video.kingiptv/play_resolve_series/{}'.format(urlencode(params))

            display_label = name if name else '{}x{}'.format(season_num, str(ep_num).zfill(2))
            list_item = xbmcgui.ListItem(display_label)
            list_item.setArt({'thumb': img, 'icon': img, 'fanart': fanart or img})

            kodi_version = int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
            if kodi_version >= 20:
                info_tag = list_item.getVideoInfoTag()
                info_tag.setTitle(name)
                info_tag.setTvShowTitle(serie_name)
                info_tag.setPlot(description)
                info_tag.setMediaType('episode')
                info_tag.setSeason(season_num)
                info_tag.setEpisode(ep_num)
            else:
                list_item.setInfo('video', {
                    'title': name,
                    'tvshowtitle': serie_name,
                    'plot': description,
                    'mediatype': 'episode',
                    'season': season_num,
                    'episode': ep_num,
                })

            playlist.add(url=plugin_url, listitem=list_item)

@route('/')
def index():
    addMenuItem({'name': TITULO, 'description': ''}, destiny='')
    addMenuItem({'name': getString(32000), 'description': ''}, destiny='/playlistiptv')
    addMenuItem({'name': getString(32001), 'description': ''}, destiny='/channels_pluto')
    addMenuItem({'name': getString(32002), 'description': ''}, destiny='/radios')
    addMenuItem({'name': getString(32003), 'description': ''}, destiny='/imdb_movies')
    addMenuItem({'name': getString(32004), 'description': ''}, destiny='/imdb_series')
    addMenuItem({'name': getString(32005)}, destiny='/settings')
    end()
    setview('WideList')

@route('/settings')
def settings():
    addon = xbmcaddon.Addon()
    addon.openSettings()

@route('/playlistiptv')
def playlistiptv():
    iptv = xtream.parselist(API_CHANNELS)
    if iptv:
        for n, (dns, username, password) in enumerate(iptv):
            n = n + 1
            addMenuItem({'name': 'LISTA {0}'.format(str(n)), 'description': '', 'dns': dns, 'username': str(username), 'password': str(password)}, destiny='/cat_channels')
        end()
        setview('WideList')
    else:
        notify(getString(32013))

@route('/cat_channels')
def cat_channels(param):
    dns = param['dns']
    username = param['username']
    password = param['password']
    xtream._ensure_epg_background(dns, username, password)
    cat = xtream.API(dns, username, password).channels_category()
    if cat:
        for i in cat:
            name, url = i
            addMenuItem({'name': name, 'description': '', 'dns': dns, 'username': str(username), 'password': str(password), 'url': url}, destiny='/open_channels')
        end()
        setview('WideList')
    else:
        url_problem = '{0}/get.php?username={1}&password={2}\n'.format(dns, username, password)
        if six.PY2:
            import io
            open_file = lambda filename, mode: io.open(filename, mode, encoding='utf-8')
        else:
            open_file = lambda filename, mode: open(filename, mode, encoding='utf-8')
        if exists(IPTV_PROBLEM_LOG):
            check = False
            with open(IPTV_PROBLEM_LOG, "r") as arquivo:
                if url_problem in arquivo.read():
                    check = True
        else:
            check = False
        with open_file(IPTV_PROBLEM_LOG, "a") as arquivo:
            if not check:
                arquivo.write(url_problem)
        notify(getString(32014))

@route('/open_channels')
def open_channels(param):
    dns = param['dns']
    username = param['username']
    password = param['password']
    url = param['url']
    open_ = xtream.API(dns, username, password).channels_open(url)
    if open_:
        setcontent('videos')
        for i in open_:
            name, link, thumb, desc = i
            addMenuItem({'name': name, 'description': desc, 'iconimage': thumb, 'url': link, 'playable': 'true'}, destiny='/play_iptv')
        end()
        setview('WideList')
    else:
        notify(getString(32015))

@route('/play_iptv')
def play_iptv(param):
    name = param.get('name', getString(32029))
    description = param.get('description', '')
    iconimage = param.get('iconimage', '')
    url = param.get('url', '')
    proxy_url = 'http://127.0.0.1:{}/?url={}'.format(_start_proxy_if_needed(), quote_plus(url))
    play_item = xbmcgui.ListItem(path=proxy_url)
    play_item.setContentLookup(False)
    play_item.setArt({"icon": iconimage or "DefaultVideo.png", "thumb": iconimage or "DefaultVideo.png"})
    play_item.setMimeType("application/vnd.apple.mpegurl")
    info_tag = play_item.getVideoInfoTag() if hasattr(play_item, 'getVideoInfoTag') else None
    if info_tag:
        info_tag.setTitle(name)
        info_tag.setPlot(description)
        info_tag.setMediaType('video')
    else:
        play_item.setInfo('video', {'title': name, 'plot': description})
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, play_item)

@route('/channels_pluto')
def channels_pluto():
    channels = pluto.playlist_pluto()
    if channels:
        setcontent('videos')
        for name, desc, thumb, url in channels:
            addMenuItem({'name': name, 'description': desc, 'iconimage': thumb, 'url': url, 'playable': 'true'}, destiny='/play_pluto')
        end()
        setview('List')
    else:
        notify(getString(32018))

@route('/play_pluto')
def play_pluto(param):
    url = param.get('url', '')
    name = param.get('name', '')
    iconimage = param.get('iconimage', '')
    desc = param.get('description', '')
    if not url:
        notify(getString(32016))
        return
    helper = inputstreamhelper.Helper('hls')
    if not helper.check_inputstream():
        return
    headers = url.split('|')[1] if '|' in url else ''
    url = url.split('|')[0] if '|' in url else url
    li = xbmcgui.ListItem(path=url)
    li.setProperty('inputstream', helper.inputstream_addon)
    li.setProperty('inputstream.adaptive.manifest_type', 'hls')
    li.setProperty('inputstream.adaptive.stream_headers', headers or 'User-Agent=Mozilla/5.0')
    li.setProperty('inputstream.adaptive.manifest_headers', headers or 'User-Agent=Mozilla/5.0')
    li.setMimeType('application/x-mpegURL')
    li.setProperty('inputstream.adaptive.live_delay', '0')
    li.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
    li.setArt({'icon': iconimage or 'DefaultVideo.png', 'thumb': iconimage or 'DefaultVideo.png'})
    tag = li.getVideoInfoTag() if hasattr(li, 'getVideoInfoTag') else None
    if tag:
        tag.setTitle(name)
        tag.setPlot(desc)
        tag.setMediaType('video')
    else:
        li.setInfo('video', {'title': name, 'plot': desc})
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)

@route('/radios')
def radios():
    radios_ = tunein.radios_list(API_RADIOS)
    if radios_:
        for i in radios_:
            name, url = i
            addMenuItem({'name': name, 'description': '', 'url': url}, destiny='/play_radio')
        end()
        setview('List')

@route('/play_radio')
def play_radio(param):
    name = param.get('name', '')
    url = param.get('url', '')
    if url:
        play_item = xbmcgui.ListItem(path=url)
        play_item.setContentLookup(False)
        play_item.setArt({"icon": "DefaultAudio.png", "thumb": "DefaultAudio.png"})
        info_tag = play_item.getVideoInfoTag() if hasattr(play_item, 'getVideoInfoTag') else None
        if info_tag:
            info_tag.setTitle(name)
            info_tag.setMediaType('song')
        else:
            play_item.setInfo('music', {'title': name})
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, play_item)

@route('/imdb_movies')
def imdb_movies():
    addMenuItem({'name': getString(32006), 'description': ''}, destiny='/find_movies')
    addMenuItem({'name': getString(32007), 'description': ''}, destiny='/imdb_movies_250')
    addMenuItem({'name': getString(32008), 'description': ''}, destiny='/imdb_movies_popular')
    end()
    setview('List')

@route('/imdb_series')
def imdb_series():
    addMenuItem({'name': getString(32009), 'description': ''}, destiny='/find_series')
    addMenuItem({'name': getString(32010), 'description': ''}, destiny='/imdb_series_250')
    addMenuItem({'name': getString(32011), 'description': ''}, destiny='/imdb_series_popular')
    end()
    setview('List')

@route('/find_movies')
def find_movies():
    keyboard = xbmc.Keyboard('', getString(32027))
    keyboard.doModal()
    if keyboard.isConfirmed():
        query = keyboard.getText()
        if query:
            results = imdb.IMDBScraper().search_movies(query)
            if results:
                setcontent('movies')
                for movie_name, image, url, description, imdb_id, original_name, year in results:
                    addMenuItem({
                        'name': '{} ({})'.format(movie_name, year) if year and year != '0' else movie_name,
                        'description': description,
                        'iconimage': image,
                        'fanart': image,
                        'url': '',
                        'imdbnumber': imdb_id,
                        'movie_name': movie_name,
                        'original_name': original_name,
                        'year': year,
                        'playable': True
                    }, destiny='/play_resolve_movies')
                end()
                setview('List')

@route('/find_series')
def find_series():
    keyboard = xbmc.Keyboard('', getString(32028))
    keyboard.doModal()
    if keyboard.isConfirmed():
        query = keyboard.getText()
        if query:
            results = imdb.IMDBScraper().search_series(query)
            if results:
                setcontent('tvshows')
                for serie_name, image, url, description, imdb_id, original_name, year in results:
                    addMenuItem({
                        'name': '{} ({})'.format(serie_name, year) if year else serie_name,
                        'description': description,
                        'iconimage': image,
                        'url': url,
                        'imdbnumber': imdb_id,
                        'serie_name': serie_name,
                        'original_name': original_name,
                        'year': year,
                    }, destiny='/open_imdb_seasons')
                end()
                setview('List')

@route('/imdb_movies_250')
def movies_250(param=None):
    page = int(param.get('page', 1)) if param else 1
    per_page = 50
    start = (page - 1) * per_page
    end_ = start + per_page
    all_items = imdb.IMDBScraper().movies_250()
    itens = all_items[start:end_]
    if itens:
        setcontent('movies')
        for movie_name, image, url, description, imdb_id, original_name, year in itens:
            addMenuItem({
                'name': '{} ({})'.format(movie_name, year) if year else movie_name,
                'description': description,
                'iconimage': image,
                'fanart': image,
                'url': '',
                'imdbnumber': imdb_id,
                'movie_name': movie_name,
                'original_name': original_name,
                'year': year,
                'playable': True
            }, destiny='/play_resolve_movies')
        if end_ < len(all_items):
            addMenuItem({'name': getString(32012), 'page': page + 1}, destiny='/imdb_movies_250')
        end()
        setview('List')

@route('/imdb_series_250')
def series_250(param=None):
    page = int(param.get('page', 1)) if param else 1
    per_page = 50
    start = (page - 1) * per_page
    end_ = start + per_page
    all_items = imdb.IMDBScraper().series_250()
    itens = all_items[start:end_]
    if itens:
        setcontent('tvshows')
        for serie_name, image, url, description, imdb_id, original_name, year in itens:
            addMenuItem({
                'name': '{} ({})'.format(serie_name, year) if year else serie_name,
                'description': description,
                'iconimage': image,
                'url': url,
                'imdbnumber': imdb_id,
                'serie_name': serie_name,
                'original_name': original_name
            }, destiny='/open_imdb_seasons')
        if end_ < len(all_items):
            addMenuItem({'name': getString(32012), 'page': page + 1}, destiny='/imdb_series_250')
        end()
        setview('List')

@route('/imdb_movies_popular')
def movies_popular(param=None):
    page = int(param.get('page', 1)) if param else 1
    per_page = 50
    start = (page - 1) * per_page
    end_ = start + per_page
    all_items = imdb.IMDBScraper().movies_popular()
    itens = all_items[start:end_]
    if itens:
        setcontent('movies')
        for movie_name, image, url, description, imdb_id, original_name, year in itens:
            addMenuItem({
                'name': '{} ({})'.format(movie_name, year) if year else movie_name,
                'description': description,
                'iconimage': image,
                'fanart': image,
                'url': '',
                'imdbnumber': imdb_id,
                'movie_name': movie_name,
                'original_name': original_name,
                'year': year,
                'playable': True
            }, destiny='/play_resolve_movies')
        if end_ < len(all_items):
            addMenuItem({'name': getString(32012), 'page': page + 1}, destiny='/imdb_movies_popular')
        end()
        setview('List')

@route('/imdb_series_popular')
def series_popular(param=None):
    page = int(param.get('page', 1)) if param else 1
    per_page = 50
    start = (page - 1) * per_page
    end_ = start + per_page
    all_items = imdb.IMDBScraper().series_popular()
    itens = all_items[start:end_]
    if itens:
        setcontent('tvshows')
        for serie_name, image, url, description, imdb_id, original_name, year in itens:
            addMenuItem({
                'name': '{} ({})'.format(serie_name, year) if year else serie_name,
                'description': description,
                'iconimage': image,
                'url': url,
                'imdbnumber': imdb_id,
                'serie_name': serie_name,
                'original_name': original_name
            }, destiny='/open_imdb_seasons')
        if end_ < len(all_items):
            addMenuItem({'name': getString(32012), 'page': page + 1}, destiny='/imdb_series_popular')
        end()
        setview('List')

@route('/open_imdb_seasons')
def open_imdb_seasons(param):
    serie_icon = param.get('iconimage', '')
    serie_name = param.get('serie_name', param.get('name', ''))
    original_name = param.get('original_name', '')
    url = param.get('url', '')
    imdb_id = param.get('imdbnumber', '')
    itens = imdb.IMDBScraper().imdb_seasons(url)
    if itens:
        setcontent('tvshows')
        for season_number, name, url_season in itens:
            addMenuItem({
                'name': name,
                'description': '',
                'iconimage': serie_icon,
                'url': url_season,
                'imdbnumber': imdb_id,
                'season': season_number,
                'serie_name': serie_name,
                'original_name': original_name
            }, destiny='/open_imdb_episodes')
        end()
        setview('List')

@route('/open_imdb_episodes')
def open_imdb_episodes(param):
    serie_icon = param.get('iconimage', '')
    serie_name = param.get('serie_name', '')
    original_name = param.get('original_name', '')
    url = param.get('url', '')
    imdb_id = param.get('imdbnumber', '')
    season = param.get('season', '')

    itens = imdb.IMDBScraper().imdb_episodes(url)
    if itens:
        get_db().save_season_episodes(
            imdb_id=imdb_id,
            season=int(season),
            serie_name=serie_name,
            original_name=original_name,
            episodes_data=itens
        )

        prefetch_skip_timestamps(
            imdb_id=imdb_id,
            season=int(season),
            episode_count=len(itens),
            database=get_db()
        )

        watched_set = get_db().get_watched_in_season(imdb_id, int(season))
        resume_map = get_db().get_season_resume_times(imdb_id, int(season))

        setcontent('episodes')
        for episode_number, name, img, fanart, description in itens:
            name_full = '{}x{} - {}'.format(season, str(episode_number).zfill(2), name)

            addMenuItem({
                'name': name_full,
                'description': description,
                'iconimage': img,
                'fanart': fanart,
                'imdbnumber': imdb_id,
                'season_num': season,
                'episode_num': str(episode_number),
                'serie_name': serie_name,
                'original_name': original_name,
                'episode_title': name,
                'mediatype': 'episode',
                'playable': True,
                'playcount': 1 if int(episode_number) in watched_set else 0,
                'resume_time': resume_map.get(int(episode_number)),
            }, destiny='/play_resolve_series')

        end()
        setview('List')

AUTO_PLAY_PRIORITY = ['abyss', 'byse', 'upns']

def _sort_players_by_priority(players):
    priority_map = {name: idx for idx, name in enumerate(AUTO_PLAY_PRIORITY)}

    def _key(item):
        search_text = ((item[0] or '') + ' ' + (item[1] or '')).lower()
        for p_name, p_idx in priority_map.items():
            if p_name in search_text:
                return p_idx
        return len(AUTO_PLAY_PRIORITY)

    resolver = Resolver()
    for source_name, stream_url in sorted(players, key=_key):
        xbmc.log('[KingIPTV] Tentando source "{}" ...'.format(source_name), xbmc.LOGINFO)
        try:
            resolved, sub = resolver.resolverurls(stream_url)
            if resolved:
                xbmc.log('[KingIPTV] Source "{}" OK.'.format(source_name), xbmc.LOGINFO)
                return resolved, sub
            xbmc.log('[KingIPTV] Source "{}" falhou. Tentando proximo...'.format(source_name), xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log('[KingIPTV] Source "{}" erro: {}. Tentando proximo...'.format(source_name, e), xbmc.LOGWARNING)

    xbmc.log('[KingIPTV] Todos os sources falharam.', xbmc.LOGERROR)
    return None, None

@route('/play_resolve_movies')
def play_resolve_movies(param):
    movie_name = param.get('movie_name', param.get('name', ''))
    iconimage = param.get('iconimage', '')
    fanart = param.get('fanart', '')
    imdb_number = param.get('imdbnumber', '')
    description = param.get('description', '')
    year = param.get('year', '')
    original_name = param.get('original_name', '')

    loading_manager.show()

    try:
        players = api_vod.VOD().movie(imdb_number)

        if not players:
            loading_manager.force_close()
            notify(getString(32016))
            return

        autoplay = xbmcaddon.Addon().getSettingBool('autoplay_enabled')

        if autoplay:
            loading_manager.set_phase3()
            stream, sub = _sort_players_by_priority(players)
        else:
            idx = loading_manager.show_source_select(players)
            if idx < 0:
                loading_manager.force_close()
                return
            loading_manager.set_phase3()
            _, raw_stream = players[idx]
            stream, sub = Resolver().resolverurls(raw_stream)

        if not stream:
            loading_manager.force_close()
            notify(getString(32016))
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
            return

        play_item = xbmcgui.ListItem(path=stream)
        play_item.setArt({'thumb': iconimage, 'icon': iconimage, 'fanart': fanart or iconimage})
        play_item.setContentLookup(False)

        stream_lower = stream.lower()
        if '.mpd' in stream_lower:
            play_item.setMimeType('application/dash+xml')
        elif '.m3u8' in stream_lower or 'hls' in stream_lower:
            play_item.setMimeType('application/x-mpegURL')
        elif stream_lower.endswith(('.mp4', '.mkv', '.avi', '.mov', '.webm', '.ts')):
            play_item.setMimeType('video/mp4')

        if sub:
            play_item.setSubtitles([sub])

        kodi_version = int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
        if kodi_version >= 20:
            info_tag = play_item.getVideoInfoTag()
            info_tag.setTitle(movie_name)
            info_tag.setPlot(description)
            info_tag.setIMDBNumber(imdb_number)
            info_tag.setMediaType('movie')
            info_tag.setOriginalTitle(original_name)
            if year:
                info_tag.setYear(int(year))
        else:
            info_dict = {
                'title': movie_name,
                'plot': description,
                'imdbnumber': imdb_number,
                'mediatype': 'movie',
                'originaltitle': original_name
            }
            if year:
                info_dict['year'] = int(year)
            play_item.setInfo('video', info_dict)

        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, play_item)
        loading_manager.close()

    except Exception as e:
        loading_manager.force_close()
        notify(getString(32016))
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())

@route('/play_resolve_series')
def play_resolve_series(param):
    serie_name = param.get('serie_name', '')
    original_name = param.get('original_name', '')
    season = param.get('season_num', '')
    episode = param.get('episode_num', '')
    episode_title = param.get('episode_title', '')
    iconimage = param.get('iconimage', '')
    fanart = param.get('fanart', '')
    imdb_number = param.get('imdbnumber', '')
    description = param.get('description', '')

    if not episode or not season:
        notify(getString(32021))
        return

    if not str(episode).isdigit() or not str(season).isdigit():
        notify(getString(32022))
        return

    current_episode_num = int(episode)
    season_num = int(season)

    if current_episode_num <= 0 or season_num <= 0:
        notify(getString(32022))
        return

    resume_data = get_db().get_resume_time(imdb_number, season_num, current_episode_num)
    resume_time = None
    if resume_data and resume_data[0] > 0:
        if ask_resume(resume_data[0]):
            resume_time = resume_data[0]
        else:
            get_db().clear_resume_time(imdb_number, season_num, current_episode_num)

    loading_manager.show()

    try:
        players = api_vod.VOD().tvshows(imdb_number, season_num, current_episode_num)

        if not players:
            loading_manager.force_close()
            notify(getString(32016))
            return

        autoplay = xbmcaddon.Addon().getSettingBool('autoplay_enabled')

        if autoplay:
            loading_manager.set_phase3()
            stream, sub = _sort_players_by_priority(players)
        else:
            idx = loading_manager.show_source_select(players)
            if idx < 0:
                loading_manager.force_close()
                return
            loading_manager.set_phase3()
            _, raw_stream = players[idx]
            stream, sub = Resolver().resolverurls(raw_stream)

        if not stream:
            loading_manager.force_close()
            notify(getString(32016))
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
            xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
            return

        playback_title = episode_title

        play_item = xbmcgui.ListItem(label=playback_title, path=stream)
        play_item.setArt({'thumb': iconimage, 'icon': iconimage, 'fanart': fanart or iconimage})
        play_item.setContentLookup(False)

        stream_lower = stream.lower()
        if '.mpd' in stream_lower:
            play_item.setMimeType('application/dash+xml')
        elif '.m3u8' in stream_lower or 'hls' in stream_lower:
            play_item.setMimeType('application/x-mpegURL')
        elif stream_lower.endswith(('.mp4', '.mkv', '.avi', '.mov', '.webm', '.ts')):
            play_item.setMimeType('video/mp4')

        if sub:
            play_item.setSubtitles([sub])

        kodi_version = int(xbmc.getInfoLabel('System.BuildVersion').split('.')[0])
        if kodi_version >= 20:
            info_tag = play_item.getVideoInfoTag()
            info_tag.setTitle(playback_title)
            info_tag.setTvShowTitle(serie_name)
            info_tag.setOriginalTitle(original_name)
            info_tag.setPlot(description)
            info_tag.setIMDBNumber(imdb_number)
            info_tag.setMediaType('episode')
            info_tag.setSeason(season_num)
            info_tag.setEpisode(current_episode_num)
        else:
            info_dict = {
                'title': playback_title,
                'tvshowtitle': serie_name,
                'originaltitle': original_name,
                'plot': description,
                'imdbnumber': imdb_number,
                'mediatype': 'episode',
                'season': season_num,
                'episode': current_episode_num,
            }
            play_item.setInfo('video', info_dict)

        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, play_item)

        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)

        if playlist.size() <= 1:
            all_episodes = get_db().get_season_episodes(imdb_number, season_num)
            if all_episodes:
                build_series_playlist(
                    imdb_number=imdb_number,
                    season_num=season_num,
                    current_episode_num=current_episode_num,
                    serie_name=serie_name,
                    original_name=original_name,
                    all_episodes=all_episodes
                )

        player = get_player()

        threading.Thread(
            target=player.start_monitoring,
            args=(imdb_number, season_num, current_episode_num),
            kwargs={'resume_time': resume_time},
            daemon=True
        ).start()

        loading_manager.close()
    except Exception as e:
        loading_manager.force_close()
        notify(getString(32016))
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
        xbmc.PlayList(xbmc.PLAYLIST_VIDEO).clear()
